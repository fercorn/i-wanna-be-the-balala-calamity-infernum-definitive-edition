SMODS.Sound{
    key="coupon_collect",
    path="coupon_collect.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="minipekka_obtain",
    path="minipekka_obtain.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="minipekka_activate",
    path="minipekka_activate.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="flying_gorilla",
    path="flying_gorilla.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="bear5",
    path="bear5.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="boshy",
    path="boshy.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="kid_blind",
    path="kid_blind.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="kid_boss",
    path="kid_boss.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="kid_death",
    path="kid_death.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="triple_coupon",
    path="triple_coupon.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="lucky",
    path="lucky.ogg",
    pitch=0.7,
    volume=0.6
}