SMODS.Enhancement {
    key = 'methcard',
    pos = { x = 3, y = 0 },
    loc_txt = {
        name = 'Meth Card',
        text = {
        [1] = '\"idk what it would do\"',
        [2] = '-Walter'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 0
}